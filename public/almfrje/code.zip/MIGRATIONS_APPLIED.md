# تعديلات قاعدة البيانات المطبّقة يدوياً

## ١) توسيع أدوار العضو (لإضافة «مشرف عام»)
مطبَّق على قاعدة الإنتاج، ومضاف للمخطّط (lib/almfrje-schema.ts) ليُطبَّق مستقبلاً:
```sql
ALTER TABLE public.almfrje_members DROP CONSTRAINT IF EXISTS almfrje_members_role_check;
ALTER TABLE public.almfrje_members
  ADD CONSTRAINT almfrje_members_role_check
  CHECK (role IN ('admin','general_manager','branch_manager','viewer'));
```

## ٢) متغيّر بيئة للنسخ السحابي المجدول
أُضيف `CRON_SECRET` في إعدادات Vercel (يحمي /api/almfrje-backup ويُفعّل مهمّة Cron اليومية).
