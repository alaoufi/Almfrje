# دليل تطوير موقع «قبيلة المفارجة» (Almfrje)

تطبيق شجرة نسب القبيلة: واجهة أمامية ثابتة (SPA بـ Vanilla JS) + مسارات Next.js خادمية + Supabase (Postgres + Auth + Storage). يُستضاف على Vercel، الدومين: `almfrje.alaoufi.me`.

---
## ١) البنية العامة
```
public/almfrje/            ← تطبيق المفرجي (الواجهة)
  index.html               الهيكل + الهيدر + وسوم المعاينة (OG)
  app.js                   كل منطق التطبيق (≈ 5000 سطر): الشاشات/الشجرة/البحث/
                           الإحصائيات/النسخ/الصلاحيات/الوثائق/الملاحظات…
  app.css                  كل التنسيقات (تصميم ثلاثي الأبعاد + متغيّرات الألوان)
  config.js                إعداد احتياطي ثابت (URL+anon)
  manifest.webmanifest     إعداد PWA
  lazma-1173*.jpg          صور وثيقة اللزمة (كاملة + مصغّرة)

app/                       ← مسارات Next.js (خادمية، Node runtime)
  almfrje-config/route.ts        تزويد إعداد المتصفّح (anon) بكاشٍ قصير
  api/almfrje-config/route.ts    نسخة no-store من الإعداد
  api/almfrje-setup/route.ts     ترقية المخطّط تلقائياً (PAT) — للمدير فقط
  api/almfrje-admin/route.ts     عمليات إدارية على المستخدمين
  api/almfrje-create-user/route.ts  إنشاء حساب (service role)
  api/almfrje-delete-person/route.ts حذف شخص (مدير)
  api/almfrje-feedback/route.ts  ملاحظات الزوّار: list/count/approve/reject/done
  api/almfrje-guest-verify/route.ts تحقّق دخول الزائر بالاسم/النسب
  api/almfrje-presence/route.ts  التواجد الآن + إحصاء الزيارات
  api/almfrje-upload/route.ts    رفع الصور/الوثائق إلى Storage
  api/almfrje-backup/route.ts    النسخ الاحتياطي السحابي (Cron + يدوي)

lib/
  almfrje-env.ts           قراءة متغيّرات البيئة (url/anon/service/pat) معزولة
  almfrje-schema.ts        مخطّط قاعدة المفرجي الكامل (SQL) + RLS — يُطبَّق عبر /api/almfrje-setup

database/                  ملفات SQL مرجعية
next.config.mjs            التوجيه (rewrites) والكاش (headers)
vercel.json                مهمّة Cron اليومية للنسخ الاحتياطي
.env.example               نموذج متغيّرات البيئة
```
> ملاحظة: المستودع يضمّ مشاريع أخرى (مراحي/ملاحظات) — تجاهلها؛ يخصّ المفرجي ما بادئته `almfrje` و`public/almfrje`.

---
## ٢) التشغيل محلياً
```bash
npm install
cp .env.example .env.local      # املأ قيم Supabase (انظر القسم ٤)
npm run dev                     # http://localhost:3000
```
التطبيق يُخدَم من الجذر `/` (rewrite إلى `public/almfrje/index.html`).

---
## ٣) النشر (Vercel)
- مربوط بفرع `main` على GitHub: كل دفعٍ إلى `main` يُنشر تلقائياً (إنتاج).
- لا حاجة لإعداد بناء خاص (Next.js يُكتشف تلقائياً).
- بعد أي تغيير في المخطّط: افتح الموقع كمدير (يشغّل `/api/almfrje-setup` بتوكنك فيُطبّق الترقية)، أو شغّل SQL يدوياً (انظر MIGRATIONS_APPLIED.md).

---
## ٤) متغيّرات البيئة (Vercel → Settings → Environment Variables)
| المتغيّر | الوصف |
|---|---|
| `ALMFRJE_SUPABASE_URL` | رابط مشروع Supabase الخاص بالمفرجي |
| `ALMFRJE_SUPABASE_ANON_KEY` | مفتاح anon العلني (يُقدَّم للمتصفّح) |
| `ALMFRJE_SERVICE_ROLE_KEY` | مفتاح الخدمة (خادمي فقط — لا يُكشف) |
| `ALMFRJE_SUPABASE_PAT` | Personal Access Token لإنشاء الجداول/الـRLS تلقائياً |
| `CRON_SECRET` | سرٌّ يحمي مسار النسخ المجدول (ترسله Vercel Cron تلقائياً) |
(يُقبل الرجوع للمشتركة `NEXT_PUBLIC_*`/`SUPABASE_*` إن لم تُضبط الخاصة — انظر `.env.example`.)

---
## ٥) قاعدة البيانات (Supabase / Postgres)
المخطّط الكامل في `lib/almfrje-schema.ts` (يُطبَّق idempotent عبر `/api/almfrje-setup`). الجداول الأساسية:
- `almfrje_persons` — الأشخاص (الشجرة): id, name, father_id, branch_id, generation, sex, status, birth, death, phone, email, city, photo_url, notes, sort, nickname, birthplace, work, field_audit, created_by_name, updated_by_name…
- `almfrje_branches` — الفروع: id, name, root_id, manager_id, notes…
- `almfrje_members` — المستخدمون والأدوار: user_id, full_name, username, phone, role (admin/general_manager/branch_manager/viewer), branch_id, branch_ids, perms (jsonb), is_active…
- `almfrje_documents` — وثائق/صور الأشخاص.
- `almfrje_settings` — كل الإعدادات النصّية (key/value jsonb): banner_text, congrats, doc/tribe_docs, share_*, visit_stats, presence, guest_*, status_labels…
- `almfrje_audit` — سجل التعديلات.  `almfrje_trash` — سلة المحذوفات.  `almfrje_feedback` — ملاحظات الزوّار.
- منظور `almfrje_persons_pub` — نسخة مُنقّاة للزوّار (تُخفي الجوال/الملاحظات).
- دوال RPC: `almfrje_claim_admin`, `almfrje_admin_wipe_persons`, `almfrje_ensure_guest`, `almfrje_resolve_login`، إلخ.
- **RLS مفعّل** على كل الجداول؛ الحماية الجذرية للبيانات عبره.

---
## ٦) الأدوار والصلاحيات
- **مدير النظام (admin):** كل شيء + أدوات إدارة الموقع.
- **مشرف عام (general_manager):** كل الفروع (أو فروعٍ محدّدة)، بصلاحيات دقيقة.
- **مشرف فرع (branch_manager):** فروعه المحدّدة فقط، بصلاحيات دقيقة.
- **زائر (viewer):** تصفّح فقط.
الصلاحيات الدقيقة (`perms` jsonb): `add_birth`, `approve_birth`, `reorder`, `edit_profile`.
كل إضافة/تعديل يُسجَّل باسم فاعله ووقته (`updated_by_name`/`updated_at` + `almfrje_audit`).

---
## ٧) أبرز الميزات (مواضعها في app.js)
- الشجرة التفاعلية، العرض الهرمي، الأعمدة، خط الأجيال، الشجرة الدائرية، فهرس الذرية.
- حاسبة صلة القرابة + المنتقي الموحّد (بحث + تصفّح هرمي).
- التقرير الإحصائي الكامل (عام/عدد كل جيل/المتوفّون/الفروع/أكبر البيوت/الأسماء/المدن/الزيارات).
- النسخ الاحتياطي (داخل القاعدة + سحابي تلقائي يومي + استعادة).
- قسم الوثائق (صورة + تفريغ نص).
- ملاحظات الزوّار + مؤشّر للمشرف.
- التهنئة/البانر/النصوص القابلة للتعديل من «التحكم ← النصوص».

---
## ٨) قواعد عمل مهمّة
- لا يجتمع حيّان بنفس الاسم: أخوان حيّان، أو ابن واسم والده الحيّ → يُمنع. (مع متوفٍّ: تحذير ويُقبل.)
- الكاش الذكي: أصول `/almfrje/*` بـ `no-cache`+ETag (تُحدَّث فور النشر، 304 سريع)؛ و`/api/*` بـ `no-store`.
- كل نصوص الواجهة تُمرَّر عبر `esc()` (منع XSS).

---
## ٩) سير التطوير
1. عدّل `public/almfrje/app.js` / `app.css` (الواجهة) أو `app/api/*` (الخادم).
2. تحقّق: `node --check public/almfrje/app.js` و`npx tsc --noEmit`.
3. ادفع إلى `main` → نشر تلقائي.
4. بعد النشر اضغط 🔄 في الموقع لجلب أحدث `app.js`.
